# Neurossistant
<div style="display:flex;">
    <img src="https://github.com/mfazrinizar/neurossistant-public/blob/main/assets/icons/logo.png?raw=true" alt="Icon" width="256"/>
    <img src="https://github.com/mfazrinizar/neurossistant-public/blob/main/assets/icons/logo_black.png?raw=true" alt="Icon" width="256"/>
</div>
